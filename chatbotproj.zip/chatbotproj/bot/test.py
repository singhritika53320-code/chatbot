# chatbot/tests.py
from django.test import TestCase
from django.urls import reverse
from .chatbot_logic import process_input, generate_response

class ChatbotTestCase(TestCase):
    def test_process_input(self):
        # Test the process_input function
        processed_input = process_input("Hello")
        self.assertEqual(processed_input, "Hello")

    def test_generate_response(self):
        # Test the generate_response function
        response = generate_response("Hello")
        self.assertIn(response, ["Hello!", "Hi there!", "Hey!"])

class ChatbotAPITestCase(TestCase):
    def test_chatbot_api(self):
        # Test your chatbot API endpoint
        response = self.client.post(reverse('chatbot'), {'user_input': 'Hello'})
        self.assertEqual(response.status_code, 200)
        self.assertIn('response', response.json())
