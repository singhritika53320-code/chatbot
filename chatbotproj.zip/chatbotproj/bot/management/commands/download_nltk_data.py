# myapp/management/commands/download_nltk_data.py
from django.core.management.base import BaseCommand
import nltk

class Command(BaseCommand):
    help = 'Download NLTK data'

    def handle(self, *args, **kwargs):
        nltk.download('punkt')
        # Add more NLTK downloads as needed
        self.stdout.write(self.style.SUCCESS('NLTK data downloaded successfully'))
