from django.db import models

# Create your models here.
#class ChatbotResponse (models.Model):
 #   timestamp= models.DateTimeField(auto_now_add=True)
  #  user = models.CharField(max_length=200)
   # response=models.CharField(max_length=200)
  