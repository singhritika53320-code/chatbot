import nltk
from nltk.chat.util import Chat, reflections

nltk.download('punkt')  # Ensure that the 'punkt' tokenizer is downloaded

pattern_response_pairs = [
    (r'hi|hello|hey', ['Hello!', 'Hi there!', 'Hey!']),
    (r'how are you', ['I am just a chatbot, but I am here to help. How can I assist you?']),
    (r'bye|goodbye', ['Goodbye!', 'See you later!', 'Have a great day!']),
]

chatbot = Chat(pattern_response_pairs, reflections)

def process_input(user_input):
    return user_input

def generate_response(processed_input):
     return chatbot.respond(processed_input)
