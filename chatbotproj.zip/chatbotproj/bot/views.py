#from django.shortcuts import render
#from django.http import JsonResponse
#from .chatbot_logic import process_input, generate_response

#def chatbot_view(request):
    #if request.method == 'POST':
        #user_input = request.POST.get('user_input', '')
        #processed_input = process_input(user_input)
        #response = generate_response(processed_input)

        #return JsonResponse({'response': response})
    #else:
      #  return JsonResponse({'error': 'hello i am ritika singh i create chatbot'})

# Create your views here.
# chatbot_app/views.py
from django.shortcuts import render , redirect
from .chatbot_logic import process_input, generate_response
#from. models import ChatbotResponse

def chatbot_home(request):
    return render(request, 'bot/chatbot_home.html')

def chatbot_response(request):
    if request.method == 'POST':
        user_input = request.POST.get('user_input',"")
        processed_input = process_input(user_input) #pass the user input to the chatbot to get response
        response= generate_response( processed_input)
        # save the interaction in to databases
        #ChatbotResponse.objects.create (user='user_input',response='processed')
       # return redirect('chatbot_home')#redirect to avoid resubmitting the form on page refresh
    
     #  chatbot_responses =ChatbotResponse.objects.all()
        return render(request, 'bot/chatbot_home.html', {'user_input':user_input,'response':response})
    else:
        return render(request, 'bot/chatbot_home.html')
